package com.blind.api.domain.like.domain;

import com.blind.api.domain.user.v2.domain.User;
import com.blind.api.global.entity.BaseTimeEntity;
import lombok.Builder;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Columns;

import javax.persistence.*;

//@Entity
@NoArgsConstructor
public class Like {
    @Id
    private Long id;

    /* ContentType 지정
    @Column(name = "type")
    private Integer type;
    */
    @JoinColumn(name = "user_id")
    @ManyToOne
    private User user;

    @Builder
    public Like(Long id, User user) {
        this.id = id;
        this.user = user;
    }
}
