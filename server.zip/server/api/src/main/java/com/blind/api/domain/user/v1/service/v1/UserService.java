package com.blind.api.domain.user.v1.service.v1;

import com.blind.api.domain.security.jwt.v1.domain.Token;
import com.blind.api.domain.security.jwt.v1.repository.TokenRepository;
import com.blind.api.domain.user.v1.domain.User;
import com.blind.api.domain.user.v1.domain.UserRefreshToken;
import com.blind.api.domain.user.v1.repository.UserRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class UserService {
    private final UserRepository userRepository;
    private final TokenRepository tokenRepository;

    public User getUserBy(String id){
        return userRepository.findByUserId(id);
    }

    /*임시 구현*/
    public User getUserByUserSeq(Long id) {

        return userRepository.findByUserSeq(id);
    }

    public User getUserByToken(String token){
        Token userToken =  tokenRepository.findByAccessToken(token)
                .orElse(null);
        if (userToken == null)
            return null;
        return userRepository.findByUserId(userToken.getHashId());
    }
}
