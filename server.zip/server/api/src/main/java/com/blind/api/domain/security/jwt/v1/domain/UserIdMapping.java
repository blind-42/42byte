package com.blind.api.domain.security.jwt.v1.domain;

import com.blind.api.domain.user.v2.domain.User;

public interface UserIdMapping {
    User getUserId();
}
