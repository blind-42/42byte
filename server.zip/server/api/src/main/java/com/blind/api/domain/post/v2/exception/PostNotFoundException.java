package com.blind.api.domain.post.v2.exception;

public class PostNotFoundException extends RuntimeException{
}
