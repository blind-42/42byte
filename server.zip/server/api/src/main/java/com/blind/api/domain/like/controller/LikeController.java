package com.blind.api.domain.like.controller;

public class LikeController {
}
